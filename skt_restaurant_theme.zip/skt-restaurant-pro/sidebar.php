<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package SKT Restaurant
 */
?>
<div id="sidebar">
    
    <?php if ( ! dynamic_sidebar( 'sidebar-main' ) ) : ?>
        <aside id="archives" class="widget">
            <h3 class="widget-title">Opening Hours</h3>
            <?php echo do_shortcode('[time_table]
[time_table_row title="Monday" start="10:00 am - to - 08:00pm"]
[time_table_row title="Tuesday" start="10:30 pm - to - 09:00pm"]
[time_table_row title="Wednesday" start="09:00 am - to - 09:30pm"]
[time_table_row title="Thursday" start="09:00 am - to - 09:30pm"]
[time_table_row title="Friday" start="09:00 am - to - 05:00pm"]
[time_table_row title="Saturday" start="09:00 am - to - 04:00pm"]
[time_table_row title="Sunday" start="Closed"]
[/time_table]'); ?>
        </aside>
        <aside id="meta" class="widget">
            <h3 class="widget-title">Reservation Form</h3>
             <?php echo do_shortcode('[contactform to_email="test@example.com" title="Contact Form"]'); ?>
        </aside>
    <?php endif; // end sidebar widget area ?>
	
</div><!-- sidebar -->