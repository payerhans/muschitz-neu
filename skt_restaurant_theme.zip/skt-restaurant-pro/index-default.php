<style>body, .feature-box p, .address, .price-table{font-family:'Arial', sans-serif;}body, .contact-form-section .address,  .accordion-box .acc-content{color:#5c5c5c;}body{font-size:13px}.header .header-inner .logo h1, .logo a{font-family:Playball;color:#ffa200;font-size:36px}.header span.tagline{color:#ffa200;}.sitenav ul{font-family:'Roboto Condensed', sans-serif;font-size:15px}.sitenav ul li a, .sitenav ul li ul li a{color:#ffffff;}.sitenav ul li a:hover, .sitenav ul li.current_page_item a{color:#ffc600; border-color:#ffc600;}#todayspecial-box h2{font-size:48px; color:#ffffff;}h2.sectiontitle{font-size:38px}h1, h2, h3, h4, h5, h6, section h1, .news h2, .testimonial-box h2, .team-col h3{font-family:'Playball', sans-serif;color:#000000}#todayspecial-box:hover h2{color:#ffc600;}.hmourmenu p{color:#ffffff;}a{color:#ffa200;}a:hover{color:#a2a2a2;}.cols-4 h2{color:#fdfdf1; font-size:28px; border-bottom:1px solid#333333; }.hmourmenu .one_half h2{color:#ffffff}.cols-4{color:#ffffff; font-style:italic;}.copyright-txt{color:#ffffff}.design-by{color:#ffffff}.header-inner, .sitenav ul li:hover > ul{background-color:rgba(0,0,0,0.3);}.officehour .one_half .commonbox{background-color:rgba(255,162,0,0.7);}.officehour .one_half .commonbox{color:#ffffff; font-size:14px; }.social-icons a{border-color:#ffffff; color:#ffffff;}.social-icons a:hover{border-color:#ffa200; color:#ffa200; }.button, #commentform input#submit, input.search-submit, .post-password-form input[type=submit], .pagination ul li .current, .pagination ul li a:hover{background-color:#ffa200; color:#ffffff; }.button:hover, #commentform input#submit:hover, input.search-submit:hover, .post-password-form input[type=submit]:hover, .pagination ul li span, .pagination ul li a{background-color:#2f241e; color:#ffffff;}h3.widget-title{color:#2c2c2c; border-bottom:1px solid #cccccc;}#footer-wrapper{background-color:#272727; border-top:6px solid #131313;}.cols-4 ul li a{color:#ffffff; font-style:italic; }.cols-4 ul li a:hover, .cols-4 ul li.current_page_item a{color:#ffa200; }.copyright-wrapper{background-color:#131313;}#Grid .mix{ background:#ffa200; float:left; background:url(<?php echo get_template_directory_uri(); ?>/images/camera-icon.png) 50% 0% no-repeat #ffa200; }.nivo-directionNav a{background:url(<?php echo get_template_directory_uri(); ?>/images/slide-nav.png) no-repeat scroll 0 0 #170f09;}.nivo-controlNav a{background-color:#170f09}.nivo-controlNav a.active{background-color:#ffa200}#menulist ul#filter li.current a{background-color:#f2f2f2; color:#ffa200}#sidebar ul li a{color:#5c5c5c}#sidebar ul li a:hover{color:#ffa200;}.button2{background-color:#ffffff; color:#000000}.time_table .time_row{border-bottom:1px solid#ffcc00}.slide_info h2{background-color:#000000; color:#ffa200; font-size:40px;}.slide_info .slide-desc{background-color:#000000; color:#ffffff; font-size:14px;}.slide_info h2, .slide_info .slide-desc{background-color:rgba(0,0,0,0.3);}.news-box, .news-box .news-content h2{border-color:#ecebeb}.controls li{color:#5c5c5c; }.controls li.active, .controls li:hover{color:#ffa200; }.slide_toggle a, .accordion-box h2, .tabs-wrapper ul.tabs li a{color:#3d3d3d}h3.clicked a, .accordion-box h2.active, .tabs-wrapper ul.tabs li a.selected{color:#ffa200}.logo img{height:36px;}
@media screen and (max-width:767px) {
	 .sitenav{background-color:#a2a2a2;}
}

</style>	
<body class="home blog logged-in">
<div class="header">
  <div class="header-inner">
    <div class="logo"> 
      <a href="<?php echo home_url('/'); ?>"> <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" / > 
       <span class="tagline">Just Another WordPress site</span>
      </a>
    </div>
    <!-- logo -->
    <div class="toggle"> <a class="toggleMenu" href="#">Menu</a> </div>
    <!-- toggle -->
    <div class="sitenav">
      <ul>
        <li class="current-menu-item current_page_item menu-item-home"> <a href="<?php echo home_url('/'); ?>">Home</a> </li>
        <li><a href="#">Sample page</a></li>
      </ul>
    </div>
    <!-- nav -->
    <div class="clear"></div>
  </div>
  <!-- header-inner -->
</div>
<!-- header -->
<div class="slider-main">
  <div id="slider" class="nivoSlider"> <img src="<?php echo get_template_directory_uri(); ?>/images/slides/slider1.jpg" alt="" title="#slidecaption1"/> </div>
  <div id="slidecaption1" class="nivo-html-caption">
    <div class="slide_info"> <a href="#">
      <h2>Restaurant & Cafe</h2>
      </a>
      <div class="slide-desc">
        <p>Aliquam vitae nunc nibh. Nam sollicitudin orci vel eros
          vulputate vestibulum. Sed bibendum felis sit amet lacus
          scelerisque facilisis</p>
        <a href="#">Read More &raquo;</a> </div>
    </div>
  </div>
<div class="clear"></div>
</div>
</div>
<!-- slider -->
<section style="background-color:#ffffff; " id="ourrestaurant" class="menu_page">
  <div class="container" >
    <div class="our-restaurant">
      <p>
      <div class="one_half "><img src="<?php echo get_template_directory_uri(); ?>/images/welcome-restaurant.png" /></div>
      <div class="one_half  last_column">
        </p>
        <h2 class="sectiontitle">Welcome to Our Restaurant</h2>
        <p>Donec porta quis justo id pulvinar. Integer sed varius velit. Sed turpis nunc, imperdiet at mi nec, maximus maximus odio. Integer vel molestie ante. Curabitur blandit, purus id scelerisque posuere, enim diam mattis odio, vitae cursus nulla ex malesuada nisi. Pellentesque facilisis ullamcorper lacus, a lobortis urna porttitor eu. Suspendisse rutrum velit tellus, id volutpat risus condimentum non. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut sit amet aliquet metus, porttitor iaculis nunc. Quisque cursus ipsum ac lacinia faucibus. Quisque id dui vulputate, varius lectus vitae, congue purus.</p>
        <p><a class="button" href="#">Read More&#8230;</a>
      </div>
      </p>
    </div>
    <!-- middle-align -->
    <div class="clear"></div>
  </div>
  <!-- container -->
</section>
<div class="clear"></div>
<section style="background-color:#f7f7f7; " id="todayspecial" class="menu_page">
  <div class="container" >
    <div class="todayspecial">
      <h2 class="sectiontitle">Today's Special</h2>
      <p>
      <div id="todayspecial-box"> <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/food.jpg" />
        <h2>Food</h2>
        </a> </div>
      <div id="todayspecial-box"> <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/drink.jpg" />
        <h2>Desert</h2>
        </a> </div>
      <div id="todayspecial-box"> <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/desert.jpg" />
        <h2>Drink</h2>
        </a> </div>
      </p>
    </div>
    <!-- middle-align -->
    <div class="clear"></div>
  </div>
  <!-- container -->
</section>
<div class="clear"></div>
<section style="background-image:url(<?php echo get_template_directory_uri(); ?>/images/ourmenu-bg.jpg); background-repeat:no-repeat; background-position: center center;" id="hmourmenu" class="menu_page">
  <div class="container" >
    <div class="hmourmenu">
      <p>
      <div class="one_half ">
        <div class="omphotobooth">
          <div class="omgallery">
            <ul class="clean" id="portfolio">
              <li class="bread coffee desert drinks food" > <strong>Menu Six</strong> <img src="<?php echo get_template_directory_uri(); ?>/images/menu3.jpg"/> </li>
              <li class="desert" > <strong>Menu Fifth</strong> <img src="<?php echo get_template_directory_uri(); ?>/images/menu6.jpg"/> </li>
              <li class="food" style="margin-right:0"> <strong>Menu Fourth</strong> <img src="<?php echo get_template_directory_uri(); ?>/images/menu3.jpg"/> </li>
              <li class="food" > <strong>Menu Third</strong> <img src="<?php echo get_template_directory_uri(); ?>/images/menu3.jpg"/> </li>
              <li class="drinks" > <strong>Menu Second</strong> <img src="<?php echo get_template_directory_uri(); ?>/images/menu6.jpg"/> </li>
              <li class="coffee" style="margin-right:0"> <strong>Menu First</strong> <img src="<?php echo get_template_directory_uri(); ?>/images/menu3.jpg"/> </li>
            </ul>
          </div>
          <div class="clear"></div>
        </div>
      </div>
      <div class="one_half  last_column">
        </p>
        <h2>Our Menu</h2>
        <p>
        <div class="MenuDesc" style="width:width;">
          <p>For those with pure food indulgence in mind, come next door and sate your desires with our ever changing internationally and seasonally inspired small plates.  We love food, lots of different food, just like you.</p>
          <p>
        </div>
        <a class="button" href="#">View the Full Menu</a></div>
      </p>
    </div>
    <!-- middle-align -->
    <div class="clear"></div>
  </div>
  <!-- container -->
</section>
<div class="clear"></div>
<section style="background-color:#ffffff; " id="news" class="menu_page">
  <div class="container" >
    <div class="latest-news">
      <h2 class="sectiontitle">Latest News</h2>
      <div class="news-box  ">
        <div class="imbbox"> <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/news.jpg" alt="" /></a> <span class="date-time">May 4<span>9:29 am</span></span> </div>
        <div class="news-content"> <a href="#">
          <h2>Donec ac ligula elit</h2>
          </a>
          <p>Donec ac ligula elit. Vestibulum veliipsumy auctor quis arcu sed, consequat portrisusi Nam erat tellus, rhoncus vel eros ultricesiy lacinia tincidunt libero Donec ac ligula</p>
          <a class="readmore" href="#">Read More...</a> </div>
        <div class="clear"></div>
      </div>
      <div class="news-box last">
        <div class="imbbox"> <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/news.jpg" alt="" /></a> <span class="date-time">May 4<span>9:27 am</span></span> </div>
        <div class="news-content"> <a href="#">
          <h2>Donec ac ligula elit</h2>
          </a>
          <p>Donec ac ligula elit. Vestibulum veliipsumy auctor quis arcu sed, consequat portrisusi Nam erat tellus, rhoncus vel eros ultricesiy lacinia tincidunt libero Donec ac ligula</p>
          <a class="readmore" href="#">Read More...</a> </div>
        <div class="clear"></div>
      </div>
      <div class="news-box  ">
        <div class="imbbox"> <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/news.jpg" alt="" /></a> <span class="date-time">May 4<span>9:26 am</span></span> </div>
        <div class="news-content"> <a href="#">
          <h2>Donec ac ligula elit</h2>
          </a>
          <p>Donec ac ligula elit. Vestibulum veliipsumy auctor quis arcu sed, consequat portrisusi Nam erat tellus, rhoncus vel eros ultricesiy lacinia tincidunt libero Donec ac ligula</p>
          <a class="readmore" href="#">Read More...</a> </div>
        <div class="clear"></div>
      </div>
      <div class="news-box last">
        <div class="imbbox"> <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/news.jpg" alt="" /></a> <span class="date-time">April 28<span>11:48 am</span></span> </div>
        <div class="news-content"> <a href="#">
          <h2>Praesent aliquamar cut.</h2>
          </a>
          <p>Donec ac ligula elit. Vestibulum veliipsumy auctor quis arcu sed, consequat portrisusi Nam erat tellus, rhoncus vel eros ultricesiy lacinia tincidunt libero Donec ac ligula</p>
          <a class="readmore" href="#">Read More...</a> </div>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
    <!-- middle-align -->
    <div class="clear"></div>
  </div>
  <!-- container -->
</section>
<div class="clear"></div>
<section style="background-color:#f7f7f7; " id="testimonials" class="menu_page">
  <div class="container" >
    <div class="testimonials">
      <h2 class="sectiontitle">Our Testimonials</h2>
      <div id="testimonials">
        <div class="quotes">
          <ul>
            <li>
              <div class="tm_thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/testimonial.jpg" alt="" /></div>
              <div class="tm_description">
                <p>Aliquam et varius orci, ut ornare justo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque augue metus, blandit vel nibh sed, sollicitudin placerat quam. Quisque id scelerisque nibh. Phasellus in orci et felis tristique finibus non quis erat. Quisque nec congue nunc, sagittis aliquet orci. Quisque pulvinar feugiat sodales. Nam fermentum tempus odio sed euismod.</p>
                <h3>Eficitur Sodale</h3>
              </div>
            </li>
            <li>
              <div class="tm_thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/testimonial.jpg" alt="" /></div>
              <div class="tm_description">
                <p>That which can be asserted Aliquam et varius orci, ut ornare justo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque augue metus, blandit vel nibh sed, sollicitudin placerat quam. Quisque id scelerisque nibh. Phasellus in orci et felis tristique finibus non quiserat. Quisque nec congue nunc, sagittis aliquet orci. Quisque pulvinar feugiat sodales euismod.</p>
                <h3>Christopher Hitchens </h3>
              </div>
            </li>
          </ul>
        </div>
        <!-- .quotes -->
      </div>
      <!-- #testimonials -->
    </div>
  </div>
  <!-- middle-align -->
  <div class="clear"></div>
  </div>
  <!-- container -->
</section>
<div class="clear"></div>
<section style="background-image:url(<?php echo get_template_directory_uri(); ?>/images/openinhour-bg.jpg); background-repeat:no-repeat; background-position: center center;" id="reservation" class="menu_page">
  <div class="container" >
    <div class="officehour">
      <div class="one_half ">
        </p>
        <h2>Reservations</h2>
        <p>
        <div class="commonbox" style="width:width;">
          <p>Aliquam et varius orci, ut ornare justo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque augue metus, blandit vel nibh sed, sollicitudin placerat quam. Quisque id scelerisque nibh. Phasellus in orci et felis tristique finibus non quis  Lorem ipsum dolor sit amet, consectetur adipiscing elit erat.</p>
          <p> <a class="button2" href="">Book Now</a>
        </div>
      </div>
      <div class="one_half  last_column">
        </p>
        <h2>Opening Hours</h2>
        <p>
        <div class="commonbox lstbx" style="width:width;">
          <div class="time_table">
            <div class="time_row"><span class="title">Monday</span><span class="start_time">10:00 am - to - 08:00pm</span></div>
            <div class="time_row"><span class="title">Tuesday</span><span class="start_time">10:30 pm - to - 09:00pm</span></div>
            <div class="time_row"><span class="title">Wednesday</span><span class="start_time">09:00 am - to - 09:30pm</span></div>
            <div class="time_row"><span class="title">Thursday</span><span class="start_time">09:00 am - to - 09:30pm</span></div>
            <div class="time_row"><span class="title">Friday</span><span class="start_time">09:00 am - to - 05:00pm</span></div>
            <div class="time_row"><span class="title">Saturday</span><span class="start_time">09:00 am - to - 04:00pm</span></div>
            <div class="time_row"><span class="title">Sunday</span><span class="start_time">Closed</span></div>
            <div class="clear"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- middle-align -->
    <div class="clear"></div>
  </div>
  <!-- container -->
</section>
<div class="clear"></div>
 <section style="background-color:#ffffff; " id="ourgallery" class="menu_page">
            	<div class="container" style="width:100%">
                    <div class="our-projects">
                                        <h2 class="sectiontitle">Photo Gallery</h2>
                                        <div class="controls"><ul><li class="filter" data-filter="all">Show All</li><li class="filter" data-filter="7">Hot Menu</li><li class="filter" data-filter="9">Offer Menu</li><li class="filter" data-filter="8">Latest Menu</li></ul></div><div class="gallery"><ul id="Grid"><li class="mix 8" >
			   <strong>Gallery 5</strong>  <a href="<?php echo get_template_directory_uri(); ?>/images/gallery3.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery3.jpg"/></a></li><li class="mix 9" >
			   <strong>Gallery 6</strong> <a href="<?php echo get_template_directory_uri(); ?>/images/gallery3.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery3.jpg"/></a></li><li class="mix 7" >
			   <strong>Gallery 7</strong> <a href="<?php echo get_template_directory_uri(); ?>/images/gallery4.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery4.jpg"/></a> </li><li class="mix 8" style="margin-right:0">
			   <strong>Gallery 8</strong>  <a href="<?php echo get_template_directory_uri(); ?>/images/gallery1.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery1.jpg"/></a></li><li class="mix 8" >
			   <strong>Gallery4</strong><a href="<?php echo get_template_directory_uri(); ?>/images/gallery3.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery3.jpg"/></a></li><li class="mix 9" >
			   <strong>Gallery3</strong><a href="<?php echo get_template_directory_uri(); ?>/images/gallery1.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery1.jpg"/></a></li><li class="mix 7" >
			   <strong>Gallery2</strong><a href="<?php echo get_template_directory_uri(); ?>/images/gallery2.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery2.jpg"/></a></li><li class="mix 7 9" style="margin-right:0">
			   <strong>Gallery1</strong> <a href="<?php echo get_template_directory_uri(); ?>/images/gallery3.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery3.jpg"/></a></li></ul></div> <div style="clear:both; min-height:20px; height:50px;"></div><center><a class="button" href="#">View Our Full Gallery</a></center></p>
                     </div><!-- middle-align -->
                    <div class="clear"></div>
                    </div><!-- container here test -->
</section>
<div class="clear"></div>
<div id="footer-wrapper">
  <div class="container">
    <div class="cols-4 widget-column-1">
      <h2>Main Menu</h2>
      <ul>
        <li class="current-menu-item current_page_item"><a href="<?php echo home_url('/'); ?>">Home</a></li>
        <li><a href="#">Sample Page</a></li>
      </ul>
    </div>
    <div class="cols-4 widget-column-2">
      <h2>Our Philosophy</h2>
      <p>Consectetur, adipisci velit, sed quiaony on numquam eius modi tempora incidunt, ut laboret dolore agnam aliquam quaeratine voluptatem. ut enim ad minima veniamting suscipit lab <br>
        <br>
        <a class="readmore" href="">Read <span>More...</span></a></p>
    </div>
    <div class="cols-4 widget-column-3">
      <h2>Follow Us</h2>
      <div class="social-icons"> <a href="#" target="_blank" class="fa fa-facebook fa-1x" title="facebook"></a> <a href="#" target="_blank" class="fa fa-twitter fa-1x" title="twitter"></a> <a href="#" target="_blank" class="fa fa-linkedin fa-1x" title="linkedin"></a> <a href="#" target="_blank" class="fa fa-pinterest fa-1x" title="pinterest"></a> <a href="#" target="_blank" class="fa fa-rss fa-1x" title="rss"></a> <a href="#" target="_blank" class="fa fa-youtube fa-1x" title="youtube"></a> <a href="#" target="_blank" class="fa fa-google-plus fa-1x" title="google-plus"></a> <a href="#" target="_blank" class="fa fa-instagram fa-1x" title="instagram"></a> <a href="#" target="_blank" class="fa fa-wordpress fa-1x" title="wordpress"></a> <a href="#" target="_blank" class="fa fa-skype fa-1x" title="skype"></a> <a href="#" target="_blank" class="fa fa-yahoo fa-1x" title="yahoo"></a> <a href="#" target="_blank" class="fa fa-flickr fa-1x" title="flickr"></a> </div>
    </div>
    <div class="cols-4 widget-column-4">
      <h2>Contact Us</h2>
      <p>100 King St, Melbourne PIC 4000, Australia</p>
      <div class="phone-no">
        <p><strong>Phone:</strong>+1 800 234 5678</p>
        <p><strong>E-mail:</strong><a href="mailto:info@sitename.com">info@sitename.com</a></p>
        <p><strong>Website:</strong><a href="http://demo.com" target="_blank">http://demo.com</a></p>
      </div>
      <div class="clear"></div>
    </div>
    <div class="clear"></div>
  </div>
  <!--end .container-->
  <div class="copyright-wrapper">
    <div class="container">
      <div class="copyright-txt">&copy; 2015 <a href="#">Restaurant and Cafe</a>. All Rights Reserved</div>
      <div class="design-by">Design by SKT Themes</div>
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>