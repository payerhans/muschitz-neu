<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package SKT Restaurant
 */
?>
<div id="footer-wrapper">
    	<div class="container">
        	
        	<?php if(!dynamic_sidebar('footer-1')) : ?>  
             <div class="cols-4 widget-column-1">      	
            	<h2><?php if( of_get_option('footerabttitle',true) != '') { echo of_get_option('footerabttitle'); }; ?></h2>
                <?php wp_nav_menu( array('theme_location'  => 'footer', 'container' => '', 'container_class' => '', 'items_wrap' => '<ul>%3$s</ul>' ) ); ?> 
              </div>                  
			<?php  endif; ?>
           
            
           
            <?php if(!dynamic_sidebar('footer-2')) : ?> 
             <div class="cols-4 widget-column-2">          
            	<h2><?php if( of_get_option('philosophytitle') != ''){ echo of_get_option('philosophytitle');}; ?></h2>
                <p><?php if( of_get_option('footerabttext') != ''){ echo of_get_option('footerabttext');}; ?></p>  
              </div>             
            <?php endif; ?>
        
            
          
            <?php if(!dynamic_sidebar('footer-3')) : ?>
              <div class="cols-4 widget-column-3">
            	<h2><?php if( of_get_option('followustitle') != '') { echo of_get_option('followustitle'); } ; ?></h2>
                <?php if( of_get_option('footersocialicons') != ''){ echo do_shortcode(of_get_option('footersocialicons', true));}; ?>
               </div>
            <?php endif; ?>
           
            
            
            <?php if(!dynamic_sidebar('footer-4')) : ?>
             <div class="cols-4 widget-column-4">
            	<h2><?php if( of_get_option('addresstitle') != '') { echo of_get_option('addresstitle'); } ; ?></h2>
                <p><?php if( of_get_option('address',true) != '') { echo of_get_option('address',true) ; } ; ?></p>
                <div class="phone-no">
                	<?php if( of_get_option('phone',true) != ''){ ?>
                		<p><strong><?php _e('Phone:','skt-restaurant'); ?></strong><?php echo of_get_option('phone'); ?></p>
                    <?php } ?>
                    <?php if( of_get_option('email',true) != '' ) { ?>
                    <p><strong><?php _e('E-mail:','skt-restaurant'); ?></strong><a href="mailto:<?php echo of_get_option('email',true); ?>"><?php echo of_get_option('email',true) ; ?></a></p>
                    <?php } ?>
                    <?php if( of_get_option('weblink',true) != ''){ ?>
                    	<p><strong><?php _e('Website:','skt-restaurant'); ?></strong><a href="<?php echo of_get_option('weblink',true); ?>" target="_blank"><?php echo of_get_option('weblink',true); ?></a></p>
                    <?php } ?>
                </div>
                <div class="clear"></div> 
                </div>             
            <?php endif; ?>           
            
            <div class="clear"></div>
        </div><!--end .container-->
        
        <div class="copyright-wrapper">
        	<div class="container">
            	<div class="copyright-txt"><?php if( of_get_option('copytext',true) != ''){ echo of_get_option('copytext',true); }; ?></div>
                <div class="design-by"><?php if( of_get_option('ftlink', true) != ''){echo of_get_option('ftlink',true);}; ?></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
<?php wp_footer(); ?>
</body>
</html>