<?php
/**
 * @package SKT Restaurant
 */
?>

<div class="article-wrapper">
<article id="post-<?php the_ID(); ?>" <?php post_class('homepage-article'); ?>>	
	<?php if (has_post_thumbnail()) { ?>
        <div class="featured-image">	
            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>	
        </div>
	<?php } ?>	
	<header class="entry-header">
		<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title();?></a></h1>
	</header><!-- .entry-header -->
</article><!-- #post-## -->
</div>