<?php
/**
 * The Template for displaying all Woocommerce.
 *
 * @package SKT Restaurant
 */
get_header(); 

if( of_get_option('woocomercelayout',true) != ''){
	$woocomercelayout = of_get_option('woocomercelayout');
}
?>

<style>
<?php
	if( of_get_option('woocomercelayout', true) == 'woocomerceleft' ){
		echo '#sidebar{ float:left !important; }'; 
	}
?>
</style>

<div class="content-area">
    <div class="container main_content_wrap">
      <div class="page_wrapper">  
                
        <section id="site-main" class="site-main <?php echo $woocomercelayout; ?>" > 
			<?php woocommerce_content(); ?>
		</section>
        
         <?php 
		if( $woocomercelayout != 'woocomercesitefull' ){
		  get_sidebar();
		} ?>
        
         <div class="clear"></div>
      </div><!--end .page_wrapper-->       
    </div>
</div>	
     
<?php get_footer(); ?>